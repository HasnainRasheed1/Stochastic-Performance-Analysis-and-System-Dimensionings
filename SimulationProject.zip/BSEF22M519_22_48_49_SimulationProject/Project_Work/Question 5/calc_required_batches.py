import pandas as pd
import math
import numpy as np

# --- Configuration ---
INPUT_FILE = "Question4__Result.xlsx"
OUTPUT_FILE = "Question5_Required_Batches.xlsx"
TARGET_ERROR = 0.01  # 1% relative error
MIN_BATCHES = 40     # Constraint from prompt (n >= 40)

def main():
    # Load the results from Task 4
    try:
        df = pd.read_excel(INPUT_FILE)
    except FileNotFoundError:
        print(f"Error: Could not find {INPUT_FILE}. Make sure you are in the correct folder.")
        return

    print("Data loaded. Calculating required batches...")
    
    required_n_list = []
    
    for index, row in df.iterrows():
        current_rel_percent = row['Relative Half-Width (%)']
        
        # Check if the value is empty/NaN (e.g. Case A, K=7)
        if pd.isna(current_rel_percent) or current_rel_percent == "":
            required_n_list.append(None)
            continue

        try:
            # Formula: n_new = n_old * (current_rel_error / target_rel_error)^2
            # We assume current_rel_percent is already in % (e.g. 0.06 means 0.06%)
            # If your excel value is 0.06, that represents 0.06%. 
            # If your excel value is 1.5, that represents 1.5%.
            
            n_req = 100 * (current_rel_percent / 1.0)**2
            
            # Apply the n >= 40 constraint
            n_final = max(MIN_BATCHES, math.ceil(n_req))
            required_n_list.append(n_final)
            
        except Exception as e:
            print(f"Skipping row {index} due to error: {e}")
            required_n_list.append(None)

    df['Required Batches (n)'] = required_n_list

    # Save
    df.to_excel(OUTPUT_FILE, index=False)
    print(f"\nCalculation complete! Results saved to {OUTPUT_FILE}")
    
    # Print a preview
    print("-" * 50)
    print(f"{'Case':<6} | {'K':<3} | {'Rel Error(%)':<12} | {'Required n':<10}")
    print("-" * 50)
    
    # Print the first few and the last few rows to verify
    for i, row in df.iterrows():
        # Only print valid rows
        if pd.notna(row['Required Batches (n)']):
            # Print specific interesting rows (start of A, B, C) or high K values
            if i < 3 or i > len(df) - 4 or (row['Queue Size (K)'] == 0):
                 print(f"{row['Case']:<6} | {row['Queue Size (K)']:<3} | {row['Relative Half-Width (%)']:<12.4f} | {int(row['Required Batches (n)']):<10}")

if __name__ == "__main__":
    main()