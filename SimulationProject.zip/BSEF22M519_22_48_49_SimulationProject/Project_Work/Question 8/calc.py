import numpy as np
import math

# --- Data from File 2 (Mean Service = 4.2) ---
# Extracted the 100 batch means from your output text
batch_means = [
    0.05146, 0.04965, 0.04949, 0.04821, 0.05189, 0.04854, 0.04747, 0.0514, 0.04855, 0.05242,
    0.04902, 0.04933, 0.05133, 0.04765, 0.04925, 0.04858, 0.05065, 0.05134, 0.04917, 0.04776,
    0.04783, 0.05046, 0.04847, 0.04615, 0.05256, 0.0508, 0.04917, 0.05043, 0.0504, 0.04981,
    0.04947, 0.04866, 0.04824, 0.05081, 0.05075, 0.04884, 0.04888, 0.04612, 0.04857, 0.04836,
    0.05003, 0.05061, 0.05081, 0.04967, 0.04972, 0.0517, 0.051, 0.04815, 0.05177, 0.04926,
    0.05058, 0.04712, 0.04574, 0.04862, 0.05115, 0.04978, 0.05046, 0.0486, 0.04976, 0.05082,
    0.04928, 0.04952, 0.04808, 0.0504, 0.05048, 0.05232, 0.05232, 0.05101, 0.04892, 0.05096,
    0.04961, 0.04956, 0.05191, 0.04792, 0.04944, 0.04995, 0.05071, 0.0497, 0.04944, 0.05265,
    0.04928, 0.05028, 0.04939, 0.04667, 0.05201, 0.05218, 0.05081, 0.051, 0.05063, 0.0515,
    0.04957, 0.04951, 0.04548, 0.05029, 0.05012, 0.05159, 0.04928, 0.05116, 0.04969, 0.04903
]

def main():
    print("--- Question 8 Calculations ---")
    
    # Part 8b: Required Batches
    # From File 2 Summary: Relative Error = 0.603804 %
    current_error = 0.603804 
    target_error = 0.5
    
    n_old = 100
    n_new = n_old * (current_error / target_error)**2
    print(f"\n[8b] Required Batches:")
    print(f"Current Error: {current_error}%")
    print(f"Target Error: {target_error}%")
    print(f"Calculation: 100 * ({current_error}/{target_error})^2 = {n_new:.2f}")
    print(f"Answer: {math.ceil(n_new)} batches")
    
    # Part 8c: Lag-1 Autocorrelation
    x = np.array(batch_means[:-1]) # First 99
    y = np.array(batch_means[1:])  # Last 99
    
    # Pearson Correlation
    r = np.corrcoef(x, y)[0, 1]
    
    print(f"\n[8c] Lag-1 Autocorrelation:")
    print(f"Correlation Coefficient: {r:.4f}")
    
    # Part 8d: Interpretation
    print(f"\n[8d] Interpretation:")
    if abs(r) < 0.1:
        print("Result: Autocorrelation is close to zero.")
        print("Conclusion: Confidence intervals are ACCURATE.")
    else:
        print("Result: Significant autocorrelation.")
        print("Conclusion: Confidence intervals are TOO SMALL.")

if __name__ == "__main__":
    main()