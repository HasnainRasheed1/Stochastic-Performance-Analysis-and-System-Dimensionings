import re

# --- Configuration ---
files = [
    {"name": "out_3a_100000.txt", "case": "A", "service": 5},
    {"name": "out_3b_100000.txt", "case": "B", "service": 4},
    {"name": "out_3c_100000.txt", "case": "C", "service": 3}
]
MEAN_ARRIVAL = 5.0

print(f"{'Case':<5} | {'Offered':<8} | {'Loss Ratio':<10} | {'Reported Rho':<12} | {'Sum (Loss+Rho)':<15} | {'Difference'}")
print("-" * 75)

for f in files:
    try:
        with open(f["name"], 'r') as file:
            content = file.read()
            
            # Extract Loss Ratio
            loss_match = re.search(r'Loss ratio:\s+([0-9\.]+)', content)
            loss = float(loss_match.group(1)) if loss_match else 0
            
            # Extract Server Utilisation (Rho)
            rho_match = re.search(r'Server utilisation rho:\s+([0-9\.]+)', content)
            rho = float(rho_match.group(1)) if rho_match else 0
            
            # Calculate Offered Load (Service / Arrival)
            offered_load = f["service"] / MEAN_ARRIVAL
            
            # Calculate Sum
            total_sum = loss + rho
            
            diff = total_sum - offered_load
            
            print(f"{f['case']:<5} | {offered_load:<8.1f} | {loss:<10.5f} | {rho:<12.5f} | {total_sum:<15.5f} | {diff:+.5f}")
            
    except FileNotFoundError:
        print(f"Error: Could not find {f['name']}")

print("-" * 75)