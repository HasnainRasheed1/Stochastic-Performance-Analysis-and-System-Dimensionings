import os
import re
import pandas as pd
import matplotlib.pyplot as plt

# --- Configuration ---
INPUT_FOLDER = '.' # Folder where your 26 text files are
OUTPUT_EXCEL = "Question4_Results.xlsx"

def parse_simulation_file(filepath):
    """Extracts Mean Loss Ratio and Relative Half-Width (%) from the file summary."""
    with open(filepath, 'r') as f:
        content = f.read()
        
    # Regex to find the summary line: "Loss ratio:  0.1365  +/- 0.0117  (8.59 %)"
    # Captures: Group 1 (Mean), Group 2 (Abs Error), Group 3 (Relative Error %)
    match = re.search(r'Loss ratio:\s+([0-9\.]+)\s+\+/-\s+[0-9\.]+\s+\(([0-9\.]+)\s*%\)', content)
    
    if match:
        mean_loss = float(match.group(1))
        rel_error = float(match.group(2)) # This is the % value
        return mean_loss, rel_error
    return None, None

def main():
    data = []
    
    # scan for files like "out_4a_k0.txt" or similar
    print("Reading files...")
    for filename in os.listdir(INPUT_FOLDER):
        if filename.endswith(".txt"):
            # Simple parser to guess Case and K from filename
            # Adjust logical checks if your naming convention is different
            case = None
            if "4a" in filename.lower() or "_a_" in filename.lower(): case = "A"
            elif "4b" in filename.lower() or "_b_" in filename.lower(): case = "B"
            elif "4c" in filename.lower() or "_c_" in filename.lower(): case = "C"
            
            # Extract Queue Size K (numbers in filename)
            # Assumes format "out_4a_k6.txt" -> finds '4', '6'. We want the '6'.
            nums = re.findall(r'\d+', filename)
            if not nums or not case: continue
            
            # Heuristic: K is usually the last number in the filename
            k_val = int(nums[-1])
            
            mean, rel_err = parse_simulation_file(os.path.join(INPUT_FOLDER, filename))
            
            if mean is not None:
                data.append({
                    "Case": case,
                    "Queue Size (K)": k_val,
                    "Loss Probability": mean,
                    "Relative Half-Width (%)": rel_err
                })
                print(f"Processed {filename}: Case {case}, K={k_val}, Loss={mean}")

    # Create DataFrame
    df = pd.DataFrame(data)
    
    if df.empty:
        print("No valid data found. Check your file names!")
        return

    # Sort for plotting
    df = df.sort_values(by=["Case", "Queue Size (K)"])
    
    # Save to Excel
    df.to_excel(OUTPUT_EXCEL, index=False)
    print(f"\nData saved to {OUTPUT_EXCEL}")

    # --- Plotting ---
    cases = ["A", "B", "C"]
    colors = {'A': 'blue', 'B': 'orange', 'C': 'green'}
    rhos = {'A': 'rho=1.0', 'B': 'rho=0.8', 'C': 'rho=0.6'}

    # Plot 1: Loss Probability vs K
    plt.figure(figsize=(10, 6))
    for case in cases:
        subset = df[df["Case"] == case]
        plt.plot(subset["Queue Size (K)"], subset["Loss Probability"], 
                 marker='o', label=f"Case {case} ({rhos[case]})", color=colors[case])
    
    plt.title("Estimated Call Loss Probability vs Queue Size")
    plt.xlabel("Queue Size (K)")
    plt.ylabel("Loss Probability")
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.legend()
    plt.savefig("Q4_Loss_Probability.png")
    plt.show()

    # Plot 2: Relative Half-Width vs K
    plt.figure(figsize=(10, 6))
    for case in cases:
        subset = df[df["Case"] == case]
        plt.plot(subset["Queue Size (K)"], subset["Relative Half-Width (%)"], 
                 marker='s', linestyle='--', label=f"Case {case} ({rhos[case]})", color=colors[case])

    plt.title("Relative Half-Size of 95% CI vs Queue Size")
    plt.xlabel("Queue Size (K)")
    plt.ylabel("Relative Half-Width (%)")
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.legend()
    plt.savefig("Q4_Relative_Precision.png")
    plt.show()

if __name__ == "__main__":
    main()