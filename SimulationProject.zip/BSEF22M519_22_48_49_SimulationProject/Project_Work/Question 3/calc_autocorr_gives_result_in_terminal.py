import os
import re
import pandas as pd
import numpy as np

# --- Configuration ---
# Folder containing your .txt files ('.' means current folder)
INPUT_FOLDER = '.' 

def get_lag1_autocorrelation(series):
    """Calculates Lag-1 Autocorrelation."""
    if len(series) < 2:
        return 0
    # Correlation between the data and itself shifted by 1
    return series.autocorr(lag=1)

def parse_and_process():
    results = []
    
    print("Reading files...")
    
    # Loop through all files in the directory
    for filename in os.listdir(INPUT_FOLDER):
        if filename.endswith(".txt"):
            filepath = os.path.join(INPUT_FOLDER, filename)
            
            # Variables to store info
            batch_means = []
            
            with open(filepath, 'r') as f:
                lines = f.readlines()
                
            # Extract Batch Means
            # Looking for lines like: "1:   0.452   ..."
            for line in lines:
                # Regex to find lines starting with a number and a colon
                match = re.match(r'^\s*(\d+):\s+([0-9\.]+)', line)
                if match:
                    try:
                        # The second group is the mean loss ratio
                        val = float(match.group(2))
                        batch_means.append(val)
                    except ValueError:
                        continue
            
            # Only process if we found batch data (n=1000 usually)
            if len(batch_means) > 10:
                # Convert to pandas Series for easy calculation
                s = pd.Series(batch_means)
                rho_lag1 = get_lag1_autocorrelation(s)
                
                # Try to guess Case and k from filename for sorting
                # Assumes format like "out_3a_1000.txt"
                case = "Unknown"
                k = 0
                if "3a" in filename.lower(): case = "A"
                elif "3b" in filename.lower(): case = "B"
                elif "3c" in filename.lower(): case = "C"
                
                # Extract numbers from filename for k
                nums = re.findall(r'\d+', filename)
                if nums:
                    # Usually the last number in filename is k (e.g., 1000 in out_3a_1000)
                    k = int(nums[-1])

                results.append({
                    "Filename": filename,
                    "Case": case,
                    "Arrivals (k)": k,
                    "Lag-1 Autocorrelation": round(rho_lag1, 4)
                })
                print(f"Processed {filename}: Lag-1 = {rho_lag1:.4f}")

    # Create DataFrame and Sort
    df = pd.DataFrame(results)
    
    # Sort by Case then by k
    if not df.empty:
        df = df.sort_values(by=["Case", "Arrivals (k)"])
        
        # Save to Excel
        output_file = "Autocorrelation_Results.xlsx"
        df.to_excel(output_file, index=False)
        print(f"\nDone! Results saved to {output_file}")
        print("-" * 30)
        print(df.to_string(index=False))
    else:
        print("No valid data found in .txt files.")

if __name__ == "__main__":
    parse_and_process()