import os
import re
import pandas as pd

# --- Configuration ---
INPUT_FOLDER = '.'  # Current folder
OUTPUT_FILE = 'All_Loss_Ratios_Raw.xlsx'

def get_loss_ratios(filepath):
    """
    Reads a simulation file and extracts the Loss Ratio column 
    (the 3rd number on each data line).
    """
    data_points = []
    
    with open(filepath, 'r') as f:
        lines = f.readlines()
        
    for line in lines:
        # Regex to match lines like: "1:   0.882   0.125   ..."
        # It skips the Batch# and Rho, and captures the Loss Ratio.
        # Structure: [Batch#:] [Rho] [LossRatio] ...
        match = re.search(r'^\s*\d+:\s+([0-9\.]+)', line)
        if match:
            try:
                # The group(1) is the Loss Ratio
                val = float(match.group(1))
                data_points.append(val)
            except ValueError:
                continue
                
    # Return only if we found the full 1000 batches (or close to it)
    if len(data_points) >= 1000:
        return data_points[:1000] # Ensure exactly 1000 rows
    return None

def main():
    print("Scanning for simulation files...")
    
    # dictionary to hold columns { "filename": [list of 1000 numbers] }
    all_data = {}
    
    # Get all .txt files and sort them nicely
    files = [f for f in os.listdir(INPUT_FOLDER) if f.endswith(".txt")]
    files.sort() 

    count = 0
    for filename in files:
        filepath = os.path.join(INPUT_FOLDER, filename)
        
        # Extract the list of 1000 loss ratios
        loss_data = get_loss_ratios(filepath)
        
        if loss_data:
            # Clean filename for Excel header (remove .txt)
            header = filename.replace('.txt', '')
            all_data[header] = loss_data
            print(f"Extracted 1000 rows from: {filename}")
            count += 1
        else:
            # Skip files that don't look like simulation outputs
            pass

    if count == 0:
        print("No valid output files found! Make sure the .txt files are in this folder.")
        return

    # Create DataFrame (Excel Table)
    print("Creating Excel file...")
    df = pd.DataFrame(all_data)

    # Save
    df.to_excel(OUTPUT_FILE, index=False)
    print(f"\nSuccess! Raw data saved to: {OUTPUT_FILE}")
    print("You can now open this file and use =CORREL() on each column.")

if __name__ == "__main__":
    main()