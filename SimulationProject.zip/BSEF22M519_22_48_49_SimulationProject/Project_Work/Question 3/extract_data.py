import os
import re
import pandas as pd

# --- Configuration ---
# Set this to the folder containing your .txt files
# Use '.' for the current directory where the script is running
INPUT_FOLDER = '.' 
OUTPUT_EXCEL = 'Simulation_Results.xlsx'

def parse_simulation_file(filepath):
    """
    Parses a single mm1.exe output file to extract parameters and results.
    """
    with open(filepath, 'r') as f:
        content = f.read()

    data = {
        "Filename": os.path.basename(filepath),
        "Seed": None,
        "Source Type": None,
        "Mean Interarrival": None,
        "Queue Size": None,
        "Server Type": None,
        "Mean Service": None,
        "Warm-up": None,
        "Batches": None,
        "Arrivals (k)": None,
        "Rho (Utilisation)": None,
        "Rho Error": None,
        "Loss Ratio": None,
        "Loss Ratio Error": None,
        "Avg Queued": None,
        "Avg Queued Error": None
    }

    # Extract Parameters using Regex
    data["Seed"] = re.search(r"Seed\?\s+(\d+)", content).group(1)
    data["Source Type"] = re.search(r"Type of source\? \{M\|D\|U\}\s+(\w)", content).group(1)
    data["Mean Interarrival"] = float(re.search(r"Mean interarrival time\?\s+([\d\.]+)", content).group(1))
    data["Queue Size"] = int(re.search(r"Queue Size\?\s+(\d+)", content).group(1))
    data["Server Type"] = re.search(r"Type of server\? \{M\|D\|U\}\s+(\w)", content).group(1)
    data["Mean Service"] = float(re.search(r"Mean service time\?\s+([\d\.]+)", content).group(1))
    data["Warm-up"] = int(re.search(r"Consider warm-up\? \(0/1\)\s+(\d)", content).group(1))
    data["Batches"] = int(re.search(r"Number of batches\?\s+(\d+)", content).group(1))
    data["Arrivals (k)"] = int(re.search(r"Number of arrivals per batch\?\s+(\d+)", content).group(1))

    # Extract Summary Statistics (at the bottom of the file)
    rho_match = re.search(r"Server utilisation rho:\s+([\d\.]+)\s+\+/-\s+([\d\.]+)", content)
    if rho_match:
        data["Rho (Utilisation)"] = float(rho_match.group(1))
        data["Rho Error"] = float(rho_match.group(2))

    loss_match = re.search(r"Loss ratio:\s+([\d\.]+)\s+\+/-\s+([\d\.]+)", content)
    if loss_match:
        data["Loss Ratio"] = float(loss_match.group(1))
        data["Loss Ratio Error"] = float(loss_match.group(2))
        
    queued_match = re.search(r"Average number of queued arrivals:\s+([\d\.]+)\s+\+/-\s+([\d\.]+)", content)
    if queued_match:
        data["Avg Queued"] = float(queued_match.group(1))
        data["Avg Queued Error"] = float(queued_match.group(2))

    return data

def main():
    all_data = []
    
    # Loop through all files in the folder
    for filename in os.listdir(INPUT_FOLDER):
        if filename.endswith(".txt"):
            filepath = os.path.join(INPUT_FOLDER, filename)
            try:
                print(f"Processing {filename}...")
                file_data = parse_simulation_file(filepath)
                all_data.append(file_data)
            except Exception as e:
                print(f"Error processing {filename}: {e}")

    # Convert to DataFrame and save to Excel
    if all_data:
        df = pd.DataFrame(all_data)
        
        # Reorder columns for better readability
        columns_order = [
            "Filename", "Arrivals (k)", "Mean Service", "Queue Size", 
            "Loss Ratio", "Loss Ratio Error", "Rho (Utilisation)", "Batches"
        ]
        # Add remaining columns that aren't in the specific order list
        existing_cols = [c for c in columns_order if c in df.columns]
        remaining_cols = [c for c in df.columns if c not in existing_cols]
        df = df[existing_cols + remaining_cols]

        df.to_excel(OUTPUT_EXCEL, index=False)
        print(f"\nSuccess! Data extracted to {OUTPUT_EXCEL}")
    else:
        print("No .txt files found or no data extracted.")

if __name__ == "__main__":
    main()